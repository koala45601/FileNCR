use [TH_HSBC_ACC]
select *from TH_HSBC_ACC
where flag = 0 and (DeleteDate= null or UserDelete = null)