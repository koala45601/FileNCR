use [TH_HSBC_ACC]
select *from TH_HSBC_ACC
where flag = 1 and (DeleteDate= null or UserDelete = null)