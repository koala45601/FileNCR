/* memory.h

   Copyright 1998, 2001 Red Hat, Inc.

This file is part of Cygwin.

This software is a copyrighted work licensed under the terms of the
Cygwin license.  Please consult the file "CYGWIN_LICENSE" for
details. */

#ifndef _MEMORY_H
#define _MEMORY_H

/* This allows more things to compile. */
#include <string.h>

#endif /* _MEMORY_H */
